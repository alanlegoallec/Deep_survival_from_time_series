import sys
from PWA_Class import Preprocessing

self = Preprocessing()
self.generate_data()
self.save_data()

# Exit
print('Done.')
sys.exit(0)
